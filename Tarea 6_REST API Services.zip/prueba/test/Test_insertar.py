import model.package_model.insertar as insertar

def test_insertar():
    # Preparar datos de prueba
    data = {
        'cve_plan': '459',
        'grado': '9',
        'clave': '578',
        'materia': 'Dibujo',
        'horas_prac': '3',
        'horas_teo': '0',
        'creditos': '1'
    }

    # Llamar a la función para insertar registro
    resultado = insertar.Insertar.insertar_registro(data)

    # Verificar si el resultado es el esperado
    assert resultado == "Registro insertado exitosamente"
