import model.package_model.buscar as buscar

def test_buscar():
    page = 1
    page_size = 10
    data, total_records = buscar.Buscar.buscar_registro(page, page_size)
    assert data is not None
    assert total_records > 0
