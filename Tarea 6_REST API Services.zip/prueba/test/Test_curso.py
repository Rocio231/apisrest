
import model.package_model.Curso as Curso


def test_obtener_datos():
    page = 1
    page_size = 10
    data, total_records = Curso.obtener_datos(page, page_size)
    assert data is not None
    assert total_records > 0





