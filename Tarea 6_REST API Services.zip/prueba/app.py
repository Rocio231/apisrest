from flask import Flask, render_template, request, url_for


from model.package_model.Curso import Curso
from model.package_model.buscar import Buscar
from model.package_model.insertar import insertar_registro
from model.package_model.borrar import borrar_registro
from model.package_model.actualizar import actualizar_registro



app = Flask(__name__)

# aqui defino la ruta del menu 
@app.route('/')
def index():
    return render_template('index.html')
# esto es para listar las materias 
@app.route('/listar')
def listar():
     # Parámetros de paginación
    page = request.args.get('page', 1, type=int)
    page_size = 15# Cantidad de registros por página

    data, total_records = Curso.obtener_datos(page,page_size)# aqui se pasan los argumentos 
    if data is not None:
        
        return render_template('lista_planes_materias.html', data=data,page=page, page_size=page_size, total_records=total_records)
    else:
        return "Error al obtener los datos de la API"
    # buscar por plan y clave 

@app.route('/buscar', methods=['GET', 'POST'])
def buscar_registro():
    if request.method == 'POST':
        cve_plan = request.form['cve_plan']
        clave = request.form['clave']
        
        data = Buscar.buscar_registro(cve_plan, clave)  # Aquí se pasan los argumentos
        if data is not None:
            return render_template('resultado.html', data=data)
        else:
            return "Error al obtener el registro"
    return render_template('buscar.html')
# insertar

@app.route('/insertar', methods=['GET', 'POST'])
def insertar():
    if request.method == 'POST':
        return insertar_registro()
    else:
        return render_template('insertar.html')
    
    #Borrar 
    
@app.route('/borrar_registro', methods=['GET', 'POST'])
def borrar():
    if request.method == 'POST':
        resultado = borrar_registro()
        return  resultado
    else:
        
        return render_template("borrar.html")
    
#actualizar prueba 

@app.route('/actualizar', methods=['GET', 'POST'])
def actualizar():
    if request.method == 'POST':
        resultado = actualizar_registro()
        return resultado
    else:
        return render_template("actualizar.html")


if __name__ == '__main__':
    app.run(debug=True)
