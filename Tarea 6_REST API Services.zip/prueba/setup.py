from setuptools import setup ,find_packages
setup(name='web',version='1.0',packages=find_packages())
### agregar a la tarea ####
#pip install -e #