from flask import Flask, request
import requests


class Buscar:
    def actualizar():
        datos_actualizados = {
        'cve_plan': request.form['cve_plan'],
        'grado': request.form['grado'],
        'clave': request.form['clave'],
        'materia': request.form['materia'],
        'horas_prac': request.form['horas_prac'],
        'horas_teo': request.form['horas_teo'],
        'creditos': request.form['creditos']
    }
        actualizar_registro(datos_actualizados)
        return "Datos actualizados correctamente"

def actualizar_registro(datos_actualizados):
    url = "https://scompcenter.com/david/rest_api_alu_materias_daw/api/update_materia.php"
    try:
        # Hacer la solicitud POST con los datos actualizados
        response = requests.post(url, data=datos_actualizados)
        
        # Comprobar el código de estado de la respuesta
        if response.status_code == 200:
            print("Registro actualizado exitosamente.")
        else:
            print(f"Error al actualizar el registro. Código de estado: {response.status_code}")
    except Exception as e:
        print("Error al hacer la solicitud:", e)