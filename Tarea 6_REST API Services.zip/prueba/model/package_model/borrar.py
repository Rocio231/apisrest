from flask import request
import requests

def borrar_registro():
    data_to_delete = {
        "cve_plan": request.form['cve_plan'],
        "grado": request.form['grado'],
        "clave": request.form['clave'],
        "materia": request.form['materia'],
        "horas_prac": request.form['horas_prac'],
        "horas_teo": request.form['horas_teo'],
        "creditos": request.form['creditos']
    }

    try:
        response = requests.post('https://scompcenter.com/david/rest_api_alu_materias_daw/api/delete_materia.php', json=data_to_delete)
        response.raise_for_status()  # Raise an exception for HTTP errors (status codes 4xx or 5xx)

        if response.status_code == 200:
            return "Registro eliminado exitosamente"
        else:
            return f"Error al eliminar registro: {response.status_code}"
    except requests.exceptions.RequestException as e:
        return f"Error al eliminar registro: {e}"
