import requests
from flask import request

class Insertar:
    @staticmethod
    def insertar_registro(data):  
        url = "https://scompcenter.com/david/rest_api_alu_materias_daw/api/create_materia.php"
        response = requests.post(url, json=data)
        return response.status_code == 200
def insertar_registro():
    if request.method == 'POST':
        data = {
            "cve_plan": request.form['cve_plan'],
            "grado": request.form['grado'],
            "clave": request.form['clave'],
            "materia": request.form['materia'],
            "horas_prac": request.form['horas_prac'],
            "horas_teo": request.form['horas_teo'],
            "creditos": request.form['creditos']
        }
        success = Insertar.insertar_registro(data)
        if success:
            return "Registro insertado exitosamente"
        else:
            return "Error al insertar el registro"
    else:
        return "Método no permitido"