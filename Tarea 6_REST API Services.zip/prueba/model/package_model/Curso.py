import requests

class Curso:
    @staticmethod
    def obtener_datos(page, page_size):
        response = requests.get("https://scompcenter.com/david/rest_api_alu_materias_daw/api/lista_planes_materias.php")
        if response.status_code == 200:
            data = response.json()
            data_list = data.get('body', [])
            total_records = len(data_list)
            start_index = (page - 1) * page_size
            end_index = min(start_index + page_size, total_records)
            current_page_data = data_list[start_index:end_index]
            return current_page_data, total_records
        else:
            return None, 0


