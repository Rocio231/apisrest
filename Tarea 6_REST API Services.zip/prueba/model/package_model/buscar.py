import requests 
from flask import request

class Buscar:
    @staticmethod
    def buscar_registro(cve_plan, clave):  
        if request.method == 'POST':
            url = f"https://scompcenter.com/david/rest_api_alu_materias_daw/api/busca_plan_materia.php?cve_plan={cve_plan}&clave={clave}"
            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                return data
            else:
                return None
        return None  