var pattern_rfc=/^[a-zA-Z]{4}(\d{6})(([a-zA-Z0-9]){3})?$/;
var pattern_tel=/^[0-9]{10}?$/;
var pattern_email=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}?$/;
var pattern_nom=/^[a-zA-Z]{3,30}?$/;
let valida_forma = () => {
    let js_rfc=getTextInputById("f_rfc");
    let js_nom=getTextInputById("f_nombre");
    let js_pat=getTextInputById("f_paterno");
    let js_mat=getTextInputById("f_materno");
    let js_emp=getTextInputById("f_id_empresa");
    let js_tel=getTextInputById("f_telefono");
    let js_ema=getTextInputById("f_email");
    let js_cur=getTextInputById("f_id_curso");

    if (js_rfc.length <= 0){
        mensaje('Error','Error en RFC','El campo RFC es obligatorio','<a href="http://asp.net">Necesitas ayuda?,</a>')
        return false;
    }
    
    else if (!pattern_rfc.test(js_rfc)) {
        mensaje('Error','Error en RFC','El RFC no cumple el formato ejemplo: PETD740712HZ2','')
        return false;
    }

    else if (js_nom.length <=0){ 
        mensaje('Error','Error en Nombre','El Nombre es obligatorio','')
        return false;
    }

    else if (js_pat.length <=0){ 
        mensaje('Error','Error en Apellido Paterno','El Apellido Paterno es obligatorio','')
        return false;
    }

    else if (js_mat.length <=0){
        mensaje('Error','Error en Apellido Materno','El Apellido Materno es obligatorio','')
        return false;
    }

    else if(!pattern_nom.test(js_nom) || !pattern_nom.test(js_pat) || !pattern_nom.test(js_mat)){
        mensaje('Error','Error en el campo nombre, apellido paterno y apellido materno, deben de tener mínimo 3 caracteres','El nombre no cumple el formato','')
        return false;
    }

    else if (js_emp.test == 0){ 
        mensaje('Error','Error en Empresa','La Empresa es obligatorio','')
        return false;
    }

    else if (js_tel.length <= "0"){ 
        mensaje('Error','Error en Télefono','El Télefono es obligatorio','')
        return false;
    }

    else if(!pattern_tel.test(js_tel)){
        mensaje('Error','Error en Telefono','El Telefono no cumple el formato deben ser solo números','')
        return false;
    }

    else if (js_ema.length <= 0){
        mensaje('Error','Error en Email','El Email es obligatorio','')
        return false;
    }

    else if (!pattern_email.test(js_ema)){
        mensaje('Error','Error en Email','El Email no cumple con el formato','')
        return false;
    }

    else if (js_cur == "0"){ 
        mensaje('Error','Error en Curso','El Curso es obligatorio','')
        return false;
    }

}

let getTextInputById = (id) => {
    return document.getElementById(id).value.trim();
}

let mensaje = (tipo,titulo,texto,liga) => {
    Swal.fire({
        icon:tipo,
        title:titulo,
        text:texto,
        footer:liga
    });
}